/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import coding.challenge.graphics.Texture;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.vecmath.Point2d;
import javax.vecmath.Vector2d;

/**
 *
 * @author Ghomez
 */
public class Challenge {

    /**Attributes*/
    
    /**challengeNo variable of Challenge*/
    int challengeNo;
    
    /**challengeWidth variable of Challenge*/
    int challengeWidth;
    
    /**challengeHeight variable of Challenge*/
    int challengeHeight;
    
    /**firstTick variable of Challenge*/
    private boolean firstTick;
    
    /**lastTick variable of Challenge*/
    private boolean lastTick;
    
    /**challengeTime variable of Challenge*/
    private int challengeTime;
    
    public List<Vector2d> attractors = new ArrayList<>();
    public List<Particle> particles = new ArrayList<>();
    
    /**random variable of Challenge*/
    public static Random random = new Random();
    
    public Vector2d gravity;
    
    
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * Challenge Constructor
     * 
     * @param ChallengeNo
     * @param w
     * @param h
     */
    public Challenge(int ChallengeNo, int w, int h){
        System.out.println("Challenge: new Challenge "+ChallengeNo+" created");
        this.challengeNo = ChallengeNo;
        this.challengeWidth = w;
        this.challengeHeight = h;
        
        setUp();
        
        init();
    }
    
    /**Public Protocol*/
    
    /**
     * setUp()
     *
     */
    private void setUp(){
        switch(challengeNo){
            case 1:
                setUpChallenge1();
                break;
        }
    }

    private void setUpChallenge1() {
        //Setup variables here for Challenge 1
        for(int i = 0; i < 20; i++){
            Vector2d v = new Vector2d(random.nextInt(challengeWidth), random.nextInt(challengeHeight));
            this.attractors.add(v);
        }
        
    }
    
    private void init(){
        Texture.clearMaps();
        

        firstTick = true;
        lastTick = false;
    }
    
    
    /**
     * render(Graphics2D g2d)
     *
     * @param g2d
     */
    public void render(Graphics2D g2d){
        //Render Challenge
        Graphics2D g2d_Challenge = g2d;
        AffineTransform oldXForm = g2d.getTransform();
        g2d_Challenge.setColor(Color.yellow);
        
        for(int i = 0; i < this.attractors.size(); i++){
            Vector2d p = new Vector2d(this.attractors.get(i).x, this.attractors.get(i).y);
            g2d_Challenge.fillOval((int) p.x, (int) p.y, 6, 6);
        }
        
        for(int k = 0; k < this.particles.size(); k++){
            Particle p = this.particles.get(k);
            for(int j = 0; j < this.attractors.size(); j++){
                p.attracted(this.attractors.get(j));
            }
            p.tick();
            p.render(g2d_Challenge);
        }
        
        //Reset Transform
        g2d.setTransform(oldXForm);
        g2d_Challenge.setTransform(oldXForm);
    }
    
    /**
     * tick()
     *
     */
    public void tick(){
        //Handle First Tick
        if(firstTick){
            firstTick = false;           
            
        }
        //Handle Last Tick
        if(lastTick){
            lastTick = false;
            
        }
        
        this.particles.add(new Particle(random.nextInt(challengeWidth), random.nextInt(challengeHeight)));
        
        if(this.particles.size() > 900){
            this.particles.remove(0);
        }
        
        challengeTime++;//Update local timer
    }
    
}
