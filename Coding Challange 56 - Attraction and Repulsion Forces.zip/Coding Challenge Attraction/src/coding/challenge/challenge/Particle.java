/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.Random;
import javax.vecmath.Vector2d;

/**
 *
 * @author Ghomez
 */
public class Particle {

    /**Attributes*/
    
    /**pos variable of Particle*/
    public Vector2d pos;
    
    /**pos variable of Particle*/
    public Vector2d prev;
    
    /**vel variable of Particle*/
    public Vector2d vel;
    
    /**acc variable of Particle*/
    public Vector2d acc;
    
    /**first variable of Particle*/
    //private final boolean first;
    
    /**random variable of Particle*/
    public static Random random = new Random();
    
    public int lifespan;
    
    public int hu;
    public float alpha;
    private AlphaComposite acomp;
    
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * Particle Constructor
     * 
     * @param x
     * @param y
     */
    public Particle(int x, int y){//, int hu, boolean first) {
        this.pos = new Vector2d(x, y);
        this.prev = new Vector2d(x, y);
        this.vel = new Vector2d(0, 0);
        this.acc = new Vector2d();
        
//        this.lifespan = 5000;
//        
//        this.alpha = random.nextFloat() + 0.1f;
//        
//        if(alpha > 1.0f) alpha = 1.0f;
//        
//        if(this.first){
//            this.vel = new Vector2f(0, random.nextInt(12) -24);
//        } else {
//            this.vel = new Vector2f(random.nextInt(22) - 12, random.nextInt(8) - 12);
//            this.vel.x *= random.nextInt(5) + 1;
//            this.vel.y *= -random.nextInt(15) + 10;
//        }
        
        
    }
    
    
    
    /**
     * render(Graphics2D g2d)
     *
     * @param g2d
     */
    public void render(Graphics2D g2d){
        //Render Challenge
        Graphics2D g2d_Particle = g2d;
        AffineTransform oldXForm = g2d.getTransform();
        
        g2d_Particle.setColor(Color.white);
        g2d_Particle.fillOval((int) this.pos.x, (int) this.pos.y, 3, 3);
        g2d_Particle.drawLine((int) this.pos.x, (int) this.pos.y, (int) this.prev.x, (int) this.prev.y);
        
        prev.x = pos.x;
        prev.y = pos.y;
        
        //Reset Transform
        g2d.setTransform(oldXForm);
        g2d_Particle.setTransform(oldXForm);
    
    }
    
    /**
     * tick()
     *
     */
    public void tick(){        
        this.vel.add(this.acc);
        this.vel.clampMax(0.1f);
        this.pos.add(this.vel);
        this.acc.scale(0);
    }
    
    
    /**
     * applyForce()
     *
     * @param target
     */
    public void attracted(Vector2d target){
        //PVector dir = target - pos
        Vector2d force = new Vector2d();
        force.set(target.x - pos.x, target.y - pos.y);
        //force.normalize();
        double mag = force.length();//getMagnitude(force);// * 4;//distance(force);
        
        if(mag < 24.0) mag = 24.0;
        if(mag > 500.0) mag = 500.0;
        
        double G = 50;
        double strength = G / (mag * mag);
        force.scale(strength);//set(strength, strength);
        
        if(mag < 25.0) force.scale(-0.3);
        
        this.acc.add(force);
    }
    
    private double getMagnitude(Vector2d vec) {
        //return Math.abs(this.pos.x - vec.x) + Math.abs(this.pos.y - vec.y);
        return Math.abs(vec.x - this.pos.x) + Math.abs(vec.y - this.pos.y);
    }
    
    
    public double distance(Vector2d vec){
        return Math.sqrt(distanceSquared(vec));
    }

    public double distanceSquared(Vector2d vec) {
        double dx = this.pos.x - vec.x;
        double dy = this.pos.y - vec.y;
        
        return dx*dx+dy*dy;
    }
    
    public double length(){
        return Math.sqrt(lengthSquared());
    }

    public double lengthSquared() {
        return this.pos.x*this.pos.x+this.pos.y*this.pos.y;
    }
    
    public void normalize(){
        mulVec(1.0/length());
    }

    public void mulVec(double factor) {
        this.pos.x *= factor;
        this.pos.y *= factor;
    }
    
    public void addToVec(Vector2d vec) {
        this.pos.x += vec.x;
        this.pos.y += vec.y;
    }
    
    public void subFromVec(Vector2d vec) {
        this.pos.x -= vec.x;
        this.pos.y -= vec.y;
    }
    
    public Vector2d addVec(Vector2d vec) {
        Vector2d v = new Vector2d();
        v.x += vec.x;
        v.y += vec.y;
        
        return v;
    }
    
    public Vector2d subVec(Vector2d vec) {
        Vector2d v = new Vector2d();
        v.x -= vec.x;
        v.y -= vec.y;
        
        return v;
    }
    
}
