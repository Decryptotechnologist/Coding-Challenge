/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import coding.challenge.fourier.CCFourier;
import coding.challenge.graphics.Texture;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.util.ArrayList;

/**
 *
 * @author Ghomez
 */
public class Challenge {

    /**Attributes*/
    
    /**challengeNo variable of Challenge*/
    int challengeNo;
    
    /**challengeWidth variable of Challenge*/
    int challengeWidth;
    
    /**challengeHeight variable of Challenge*/
    int challengeHeight;
    
    /**firstTick variable of Challenge*/
    private boolean firstTick;
    
    /**lastTick variable of Challenge*/
    private boolean lastTick;
    
    /**challengeTime variable of Challenge*/
    private double challengeTime;
    
    /**fourierRadius variable of Challenge*/
    int fourierRadius;
    
    /**fourierRadius variable of Challenge*/
    int MAX_WAVE = 4000;
    
    /**Enemi0 variable of Enemy object */
    public int[] wave = new int[MAX_WAVE];
    
    
    private int challengeCount;
    private int[] waveX = new int[MAX_WAVE];
    private int[] waveY = new int[MAX_WAVE];
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * Challenge Constructor
     * 
     * @param ChallengeNo
     * @param w
     * @param h
     */
    public Challenge(int ChallengeNo){//, int w, int h){
        System.out.println("Challenge: new Challenge "+ChallengeNo+" created");
        this.challengeNo = ChallengeNo;
        //this.challengeWidth = w;
        //this.challengeHeight = h;
        
        setUp();
        
        init();
    }
    
    /**Public Protocol*/
    
    /**
     * setUp()
     *
     */
    private void setUp(){
        switch(challengeNo){
            case 1:
                setUpChallenge1();
                break;
        }
    }

    private void setUpChallenge1() {
        //Setup variables here for Challenge 1
        
        fourierRadius = 100;
    }
    
    private void init(){
        Texture.clearMaps();
        

        firstTick = true;
        lastTick = false;
    }
    
    
    /**
     * render(Graphics2D g2d)
     *
     * @param g2d
     */
    public void render(Graphics2D g2d){
        //Render Challenge
        Graphics2D g2d_Challenge = g2d;
        AffineTransform oldXForm = g2d.getTransform();
        
        //Background(0) translated to >>
//        g2d_Challenge.setColor(Color.black);
//        g2d_Challenge.fillRect(0, 0, CCFourier.getMainWidth()/2, CCFourier.getMainHeight()/2);

        g2d_Challenge.translate(50, 200);
        
        //let radius = 100; translated to >>
       // int fourierRadius = 100;
        
        //stroke(255);
        //noFill();
        //ellipse(0, 0, radius * 2); translated to >>
        
        g2d_Challenge.setColor(Color.white);
        g2d_Challenge.drawOval(-6, -6, fourierRadius * 2, fourierRadius * 2);
        
        double xx = fourierRadius * Math.cos(challengeTime) + 90;
        double yy = fourierRadius * Math.sin(challengeTime) + 90;
        int x = (int) xx;
        int y = (int) yy;
        
        wave[challengeCount] = y;
        
        g2d_Challenge.drawLine(90, 90, x, y);
        g2d_Challenge.fillOval(x, y, 8, 8);
        
        
        g2d_Challenge.translate(300, 0);
        g2d_Challenge.drawLine(x - 300, y, 0, wave[0]);
        
        for(int i = 0; i < wave.length; i++){
            //g2d_Challenge.drawOval(i, wave[i], 1, 1);
            waveX[i]= i;
            waveY[i] = wave[i];            
        }
        
        GeneralPath polyline = new GeneralPath(GeneralPath.WIND_EVEN_ODD, waveX.length/2);
        
        polyline.moveTo(waveX[0], waveY[0]);
        for(int index = 1; index < waveX.length; index++){
            polyline.lineTo(waveX[index], waveY[index]);
        }
        
        g2d_Challenge.draw(polyline);
        
        g2d.setTransform(oldXForm);
        g2d_Challenge.setTransform(oldXForm);
        
        
        if(challengeCount < MAX_WAVE-1){
            challengeCount++;
        } else {
            challengeCount = 0;
        }
    }
    
    /**
     * tick()
     *
     */
    public void tick(){
        //Handle First Tick
        if(firstTick){
            firstTick = false;
        }
        //Handle Last Tick
        if(lastTick){
            lastTick = false;
        }
        
        challengeTime += 0.1;//Update local timer
    }
    
}
