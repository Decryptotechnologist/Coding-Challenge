/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.graphics;

/**
 *
 * @author Ghomez
 */
public class Render {

    /**Attributes*/
    
    /**Attributes*/
    int width;
    
    /**Attributes*/
    int height;
    
    /**Attributes*/
    int[] pixels;
    
    /**Attributes*/
    static String chars = "" + //
            "abcdefghijklmnopqrstuvw" + //
            "xyz0123456789#!";
    
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * Render Constructor
     * 
     * 
     * @param width
     * @param height
     */
    public Render(int width, int height) {
        //System.out.println("Render: New Render created");
        this.width = width;
        this.height = height;
        pixels = new int[width * height];
    }
    
    
    /**
     * drawText(String msg, int scale, int x, int y, int col)
     * 
     * 
     * @param msg
     * @param scale
     * @param x
     * @param y
     * @param col
     */
    public void drawText(String msg, int scale, int x, int y, int col){
        for(int i = 0; i < msg.length(); i++){
            int ch = chars.indexOf(msg.charAt(i));
            if(ch < 0){
                continue;
            }
            
            int xx = ch % 42;
            int yy = ch / 42;
            //scaleDraw(Texture.spriteSheet1, x + i * 16, y, xx * 6, yy * 8, 5, 8, col);
        }
    }

    /**
     * scaleDraw(Render spriteSheet1, int i, int y, int i0, int i1, int i2, int i3, int col) {
     * 
     * 
     * @param x
     * @param y
     * @param x0
     * @param y0
     * @param w
     * @param h
     * @param col
     */
    private void scaleDraw(Render spriteSheet1, int x, int y, int x0, int y0, int w, int h, int col) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
