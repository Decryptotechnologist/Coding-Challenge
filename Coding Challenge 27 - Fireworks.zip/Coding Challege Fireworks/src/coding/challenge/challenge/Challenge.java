/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import coding.challenge.graphics.Texture;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import javax.vecmath.Vector2f;

/**
 *
 * @author Ghomez
 */
public class Challenge {

    /**Attributes*/
    
    /**challengeNo variable of Challenge*/
    int challengeNo;
    
    /**challengeWidth variable of Challenge*/
    int challengeWidth;
    
    /**challengeHeight variable of Challenge*/
    int challengeHeight;
    
    /**firstTick variable of Challenge*/
    private boolean firstTick;
    
    /**lastTick variable of Challenge*/
    private boolean lastTick;
    
    /**challengeTime variable of Challenge*/
    private int challengeTime;
    
    /**random variable of Challenge*/
    public static Random random = new Random();
    
    
    /**Links*/
    
    /**firework Particle of Challenge*/
    public Particle firework;
    //public Firework[] fireworks = new Firework[2];
    public List<Firework> fireworks;// = new ArrayList<>();
    public Vector2f gravity;
    
    
    
    /**Constructor*/
    
    /**
     * Challenge Constructor
     * 
     * @param ChallengeNo
     * @param w
     * @param h
     */
    public Challenge(int ChallengeNo, int w, int h){
        System.out.println("Challenge: new Challenge "+ChallengeNo+" created");
        this.challengeNo = ChallengeNo;
        this.challengeWidth = w;
        this.challengeHeight = h;
        this.fireworks = new ArrayList<>();
        setUp();
        
        init();
    }
    
    /**Public Protocol*/
    
    /**
     * setUp()
     *
     */
    private void setUp(){
        switch(challengeNo){
            case 1:
                setUpChallenge1();
                break;
        }
    }

    private void setUpChallenge1() {
        //Setup variables here for Challenge 1
        gravity = new Vector2f(0, 0.369f);
        //firework = new Particle(random.nextInt(challengeWidth), challengeHeight);
        
        //this.fireworks.add(new Firework(challengeWidth, challengeHeight, gravity));
        //this.fireworks[1] = new Firework(challengeWidth, challengeHeight, gravity);
        
    }
    
    private void init(){
        Texture.clearMaps();
        
        

        firstTick = true;
        lastTick = false;
    }
    
    
    /**
     * render(Graphics2D g2d)
     *
     * @param g2d
     */
    public void render(Graphics2D g2d){
        //Render Challenge
        Graphics2D g2d_Challenge = g2d;
        AffineTransform oldXForm = g2d.getTransform();
        
        //firework.render(g2d);
        
        for (Firework fw1 : this.fireworks) {
            fw1.render(g2d);
        }
        
        //Reset Transform
        g2d.setTransform(oldXForm);
        g2d_Challenge.setTransform(oldXForm);
    
    }
    
    /**
     * tick()
     *
     */
    public void tick(){
        //Handle First Tick
        if(firstTick){
            firstTick = false;
            //Game.resetGameTime();//Reset Game Timer(Optional)
            
            
        }
        //Handle Last Tick
        if(lastTick){
            lastTick = false;
//            Sound.stopAll();
//            if(!Sound.endOfLevel.isPlaying()){
//                Sound.endOfLevel.play();
//            }
            
        }
        //firework.applyForce(gravity);
        //firework.tick();//Tick (update) other classes
        if(random.nextInt(10) < 0.1){
            this.fireworks.add(new Firework(challengeWidth, challengeHeight, gravity));
        }
        
        
        for (Firework fw1 : this.fireworks) {
            if(fw1.exploded){// && this.particles.length == 0){
                this.fireworks.remove(fw1);
                break;
            } else {
                fw1.tick();
            }
        }
        
        challengeTime++;//Update local timer
    }
    
}
