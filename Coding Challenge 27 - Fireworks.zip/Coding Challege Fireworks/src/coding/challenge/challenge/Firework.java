/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.vecmath.Vector2f;

/**
 *
 * @author Ghomez
 */
public class Firework {
    
    /**Attributes*/
    
    /**random variable of Firework*/
    public static Random random = new Random();
    
    /**random variable of Firework*/
    public Vector2f gravity;
    
    /**random variable of Firework*/
    public List<Particle> particles;
    
    /**random variable of Firework*/
    public boolean exploded;
    
    /**random variable of Firework*/
    private final int hu;
    
    
    /**Links*/
    
    /**firework Particle of Firework*/
    public Particle firework;
    
    
    
    
    
    /**Constructor*/
    
    /**
     * Firework Constructor
     * 
     * @param w
     * @param h
     * @param g
     */
    public Firework(int w, int h, Vector2f g) {
        this.hu = random.nextInt(0x999999) + 0x999999;
        this.firework = new Particle(random.nextInt(w), h, this.hu, true);
        this.exploded = false;
        this.gravity = g;
        this.particles = new ArrayList<>(500);
    }
    
    
    
    /**
     * render(Graphics2D g2d)
     *
     * @param g2d
     */
    public void render(Graphics2D g2d){
        //Render Challenge
        Graphics2D g2d_Particle = g2d;
        AffineTransform oldXForm = g2d.getTransform();
    
        if(this.firework.lifespan > 0){
            this.firework.render(g2d);
        }
        
        for(Particle p: this.particles){
            if(p.lifespan > 0){
                p.render(g2d);
            }
        }
        
        //Reset Transform
        g2d.setTransform(oldXForm);
        g2d_Particle.setTransform(oldXForm);
    }
    
    
    /**
     * tick()
     *
     */
    public void tick(){
        if(!this.exploded){
            this.firework.applyForce(this.gravity);
            this.firework.tick();
            if(this.firework.vel.y >= 0){
                this.exploded = true;
                this.explode();
            }
        }
        
        for(Particle p: this.particles){
            p.applyForce(this.gravity);
            p.applyForce(this.gravity);
            p.tick();
        }
    }

    private void explode() {
        for(int i = 0; i < 100 + random.nextInt(200); i++){
            this.particles.add(new Particle(this.firework.pos.x, this.firework.pos.y, this.hu, false));
        }
    }
    
    
}
