/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.Random;
import javax.vecmath.Vector2f;

/**
 *
 * @author Ghomez
 */
public class Particle {

    /**Attributes*/
    
    /**pos variable of Particle*/
    public Vector2f pos;
    
    /**vel variable of Particle*/
    public Vector2f vel;
    
    /**acc variable of Particle*/
    public Vector2f acc;
    
    /**first variable of Particle*/
    private final boolean first;
    
    /**random variable of Particle*/
    public static Random random = new Random();
    
    public int lifespan;
    
    public int hu;
    public float alpha;
    private AlphaComposite acomp;
    
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * Particle Constructor
     * 
     * @param x
     * @param y
     * @param hu
     * @param first
     */
    public Particle(float x, float y, int hu, boolean first) {
        this.pos = new Vector2f(x, y);
        this.first = first;
        this.lifespan = 5000;
        this.hu = hu;
        this.acc = new Vector2f(0, 1.3f);
        this.alpha = random.nextFloat() + 0.1f;
        
        if(alpha > 1.0f) alpha = 1.0f;
        
        if(this.first){
            this.vel = new Vector2f(0, random.nextInt(12) -24);
        } else {
            this.vel = new Vector2f(random.nextInt(22) - 12, random.nextInt(8) - 12);
            this.vel.x *= random.nextInt(5) + 1;
            this.vel.y *= -random.nextInt(15) + 10;
        }
        
        
    }
    
    
    
    /**
     * render(Graphics2D g2d)
     *
     * @param g2d
     */
    public void render(Graphics2D g2d){
        //Render Challenge
        Graphics2D g2d_Particle = g2d;
        AffineTransform oldXForm = g2d.getTransform();
        g2d_Particle.setPaintMode();
        
        acomp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, this.alpha);
        g2d_Particle.setComposite(acomp);
        
        if(this.lifespan > 0){
            if(!this.first){
                g2d_Particle.setColor(new Color(hu).brighter().brighter().brighter());
                g2d_Particle.drawOval((int) this.pos.x, (int) this.pos.y, random.nextInt(4), random.nextInt(4));
            } else {
                g2d_Particle.setColor(new Color(hu).brighter().brighter());
                g2d_Particle.fillOval((int) this.pos.x, (int) this.pos.y, 6, 6);
            }
        }
        
        //Reset Alpha
        acomp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f);
        g2d_Particle.setComposite(acomp);
        
        //Reset Transform
        g2d.setTransform(oldXForm);
        g2d_Particle.setTransform(oldXForm);
    
    }
    
    /**
     * tick()
     *
     */
    public void tick(){
        if(!this.first){
            this.vel.setX(random.nextInt(226)-78);
            this.vel.setY(random.nextInt(246)-98);
            this.vel.scale(random.nextFloat());
            this.lifespan -= 0.02;
        }
        
        this.vel.add(this.acc);
        this.pos.add(this.vel);
        this.acc.scale(0);
    }
    
    
    /**
     * applyForce()
     *
     * @param force
     */
    public void applyForce(Vector2f force){
        this.acc.add(force);
    }
}
