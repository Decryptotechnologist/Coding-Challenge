/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import coding.challenge.clock.CCClock;
import coding.challenge.graphics.Texture;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.Calendar;
import java.util.Random;

/**
 *
 * @author Ghomez
 */
public class Challenge {

    /**Attributes*/
    
    /**challengeNo variable of Challenge*/
    int challengeNo;
    
    /**challengeWidth variable of Challenge*/
    int challengeWidth;
    
    /**challengeHeight variable of Challenge*/
    int challengeHeight;
    
    /**firstTick variable of Challenge*/
    private boolean firstTick;
    
    /**lastTick variable of Challenge*/
    private boolean lastTick;
    
    /**random variable of Challenge*/
    public static Random random = new Random();
    
    /**clockTime variable of Challenge*/
    private String clockTime;
    
    /**hrs variable of Challenge*/
    private int hrs;
    
    /**min variable of Challenge*/
    private int min;
    
    /**sec variable of Challenge*/
    private int sec;
    
    /**second variable of Challenge*/
    private String second;
    
    /**now variable of Challenge*/
    Calendar now;
    
    /**digiTextBG variable of Challenge*/
    Color digiTextBG;
    
    /**digiTextFG variable of Challenge*/
    Color digiTextFG;
    
    /**digiTextFG variable of Challenge*/
    float secAlpha = 0f;
    private AlphaComposite acomp;
    private String minute;
    private Color hourArc;
    private Color minArc;
    private Color secondArc;
    
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * Challenge Constructor
     * 
     * @param ChallengeNo
     */
    public Challenge(int ChallengeNo){
        System.out.println("Challenge: new Challenge "+ChallengeNo+" created");
        this.challengeNo = ChallengeNo;
        
        setUp();
        
        init();
    }
    
    /**Public Protocol*/
    
    /**
     * setUp()
     *
     */
    private void setUp(){
        switch(challengeNo){
            case 1:
                setUpChallenge1();
                break;
        }
    }

    private void setUpChallenge1() {
        //Setup variables here for Challenge 1
        
        
    }
    
    private void init(){
        Texture.clearMaps(); 
        
        now = Calendar.getInstance();
        
        hrs = now.get(Calendar.HOUR);// + 1;
        min = now.get(Calendar.MINUTE);
        sec = now.get(Calendar.SECOND);
        
        if(sec < 10) {
            second = "0"+now.get(Calendar.SECOND);
            clockTime = hrs+":"+min+":"+second;
        } else {        
            clockTime = hrs+":"+min+":"+sec;
        }

        firstTick = true;
        lastTick = false;
    }
    
    
    /**
     * render(Graphics2D g2d)
     *
     * @param g2d
     */
    public void render(Graphics2D g2d){
        //Render Challenge
        Graphics2D g2d_Challenge = g2d;
        AffineTransform oldXForm = g2d.getTransform();
        
        //Background(0) translated to >>
//        g2d_Challenge.setColor(getRandomColor());
//        g2d_Challenge.fillRect(0, 0, CCClock.getMainWidth()/2, CCClock.getMainHeight()/2);

        //Draws Hours Arc
        acomp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, secAlpha + (1.0f/12) * hrs);
        g2d_Challenge.setComposite(acomp);
        
        g2d_Challenge.setColor(hourArc);
        g2d_Challenge.fillArc(50, 50, 540, 540, 90, ((-360/12) * hrs));
        
        //Reset Alpha
        acomp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f);
        g2d_Challenge.setComposite(acomp);
        
        
        
        //Draws Minutes Arc
        acomp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, secAlpha + (1.0f/60) * min);
        g2d_Challenge.setComposite(acomp);
        
        g2d_Challenge.setColor(minArc);
        g2d_Challenge.fillArc(70, 70, 500, 500, 90, ((-360/60) * min));
        
        //Reset Alpha
        acomp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f);
        g2d_Challenge.setComposite(acomp);
        
        
        
        //Draws Seconds Arc
        acomp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, secAlpha + (1.0f/60) * sec);
        g2d_Challenge.setComposite(acomp);
            
        g2d_Challenge.setColor(secondArc);
        g2d_Challenge.fillArc(90, 90, 460, 460, 90, ((-360/60) * sec));
        
        //Reset Alpha
        acomp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f);
        g2d_Challenge.setComposite(acomp);
        
        
        
        
        //Start of Original clock
        g2d_Challenge.setColor(digiTextBG);
        //g2d_Challenge.setFont(new Font("default", Font.BOLD, 48));
        //g2d_Challenge.drawString(clockTime, CCClock.getMainWidth()/2 - (clockTime.length() * 12)+2, CCClock.getMainHeight()/2 + 2);
        g2d_Challenge.setFont(new Font("default", Font.BOLD, 72));
        g2d_Challenge.drawString(clockTime, CCClock.getMainWidth()/2 - (clockTime.length() * 18)+3, CCClock.getMainHeight()/2 + 3);
        g2d_Challenge.setColor(digiTextFG);
        g2d_Challenge.drawString(clockTime, CCClock.getMainWidth()/2 - (clockTime.length() * 18), CCClock.getMainHeight()/2);
        
        
        
        
        g2d.setTransform(oldXForm);
        g2d_Challenge.setTransform(oldXForm);
    }
    
    /**
     * tick()
     *
     */
    public void tick(){
        //Handle First Tick
        if(firstTick){
            firstTick = false;
            
            
            digiTextBG = getRandomColor();
            digiTextFG = digiTextBG.brighter();//.brighter();
            digiTextBG = digiTextBG.darker();
            
            hourArc = getRandomColor();
            minArc = getRandomColor();//hourArc.brighter();
            secondArc = hourArc.darker();
        }
        //Handle Last Tick
        if(lastTick){
            lastTick = false;            
        }
        
        now = Calendar.getInstance();
        
        hrs = now.get(Calendar.HOUR);// + 1;
        min = now.get(Calendar.MINUTE);
        sec = now.get(Calendar.SECOND);
        random = new Random(System.nanoTime());
        
        if(System.nanoTime() / 450 % 20 == 0){
            digiTextBG = getRandomColor();
            digiTextFG = digiTextBG.brighter();
            digiTextBG = digiTextBG.darker();
        }
        
        if(System.nanoTime() / 150 % 20 == 0){            
            hourArc = getRandomColor();
            minArc = getRandomColor().brighter();
            secondArc = hourArc.darker();
        }
        
        if(sec < 10) {
            second = "0"+now.get(Calendar.SECOND);
            if(min < 10) {
                minute = "0"+now.get(Calendar.MINUTE);
                clockTime = hrs+":"+minute+":"+second;
            } else{
                clockTime = hrs+":"+min+":"+second;
            }
        } else {    
            if(min < 10) {
                minute = "0"+now.get(Calendar.MINUTE);
                clockTime = hrs+":"+minute+":"+sec;
            } else{
                clockTime = hrs+":"+min+":"+sec;
            }
        }
    }
    
    /**
     * getRandomColor()
     *
     */
    private Color getRandomColor() {
        int r = random.nextInt(255);
        int b = random.nextInt(255);
        int g = random.nextInt(255);
        
        return new Color(r, b, g);//.brighter();
    }
    
}
