/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.clock;

import coding.challenge.challenge.Challenge;
import coding.challenge.input.*;
import java.awt.*;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

/**
 *
 * @author Ghomez
 */
public class Game extends Canvas implements Runnable {

    /**Attributes*/
    
    /**TITLE variable of Game*/
    static String TITLE = "Coding Challange #74 Clock";
    
    /**version variable of Game*/
    static String version = "v0.0.0";
    
    /**textCount variable of Game*/
    public static int textCount;
    
    /**renderCount variable of Game*/
    public static int renderCount;
    
    /**renderCount variable of Game*/
    private final BufferedImage img;
    
    /**gameSndOn variable of Game*/
    static boolean gameSndOn = true;
    
    /**gameTimer variable of Game*/
    int gameTimer = 0;
    
    /**gameTimer variable of Game*/
    int gameScore = 0;
    
    /**paused variable of Game*/
    public boolean paused;

    /**running variable of Game*/
    private boolean running;
    
    /**thread variable of Game*/
    private Thread thread;
    
    /**pixels variable of Game*/
    int[] pixels;
    
    /**frames variable of Game*/
    private int frames;
    
    /**currentTime variable of Game*/
    private long currentTime;
    
    /**fps variable of Game*/
    private int fps;
    
    /**ups variable of Game*/
    private int ups;
    
    /**theFPS variable of Game*/
    private String theFPS = 0+"FPS";
    
    /**theUPS variable of Game*/
    private String theUPS;
    
    /**gameWidth variable of Game*/
    private final int gameWidth;
    
    /**gameHeight variable of Game*/
    private final int gameHeight;
    
    /**bs variable of Game*/
    private BufferStrategy bs;
    
    
    /**Links*/
    
    /**input KeyInput of Game*/
    KeyInput input;
    
    /**mouseInput MouseInput of Game*/
    MouseInput mouseInput;
    
    /**challenge Challenge of Game*/
    Challenge challenge;
    
    
    
    
    /**Constructor*/
    
    
    /**
     * Game()
     * 
     * @param width
     * @param height
     */
    public Game(int width, int height){
        System.out.println("Game: New Game created: "+width+" * "+height+" = "+(width * height)+" pixels");
        this.gameWidth = width;
        this.gameHeight = height;
        
        //Create Keys and/or Mouse Inputs
        input = new KeyInput();
        mouseInput = new MouseInput();
        
        //Set Keys and Mouse
        addKeyListener(input);//Set Game KeyListener to input
        addFocusListener(input);//Set Game FocusListener to input
        addMouseListener(mouseInput);//Set Game mouseListener to mouseInput
        addMouseMotionListener(mouseInput);//Set Game mouseMotionListener to mouseInput
        
        //Create new blank Buffered Image
        img = new BufferedImage(CCClock.getMainWidth(), CCClock.getMainHeight(), BufferedImage.TYPE_INT_RGB);
        //Grab pixel data from img
        pixels = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
        
        //Set Game Sound
        Game.gameSndOn = Game.getGameSound();
        
        resetScore();
        resetGameTime();
        paused = false;
        
        init();//Initiate the game
        
    }
    
    /**Public Protocol*/
    
    /**
     * init()
     */
    private void init(){
        System.out.println("Game: Initiating Game . . .");
        
        challenge = new Challenge(1);
        
        start();//start the game
    }
    
    
    
    ///////THREAD MANAGEMENT START
    /**
     * start()
     */
    private void start(){
        System.out.println("Game: Starting Game . . .");
        if(running) return;
        
        running = true;
        thread = new Thread(this, "Game-Thread");
        thread.start();
    }
    
    
    /**
     * stop()
     */
    public void stop(){
        System.out.println("Game: Stopping Game . . .");
        if(!running) return;
        
        running = false;
    }
    
    
    /**
     * run()
     */
    @Override
    public void run(){
        System.out.println("Running Game . . .");
        double ns = 1000000000.0 / 60;//Update 60 times per second ||
        //double ns = 1000000000.0 / 30;//Update 30 times per second
        long prevTime = System.nanoTime();
        double delta = 0;
        frames = 0;
        
        int updates = 0;
        long timer = System.currentTimeMillis();
        
        while(running){
            currentTime = System.nanoTime();
            delta += (currentTime - prevTime) / ns;
            prevTime = currentTime;
            
            if(delta >= 1){
                tick();
                updates++;
                delta--;
            }
            
            while(System.currentTimeMillis() - timer > 1000){
                timer += 1000;
                gameTimer += 1;
                //Game.gameScore = score;
                
                fps = frames;
                ups = updates;
                
                theFPS = fps+"FPS";
                theUPS = ups+"UPS";
                
                frames = 0;
                updates = 0;
            }
            render();
            frames++;
            //setScore(score);
        }
    }
    ///////THREAD MANAGEMENT END
    
    
    
    
    /**
     * tick() AKA Update()
     */
    private void tick(){        
        //input.tick(this, this.menu, this.player);//Render another class using args Game, menu, player
        challenge.tick();//Render another class using no args
    }
    
    
    /**
     * render() AKA Draw()
     */
    private void render(){
        //Get Buffer Strategy
        bs = getBufferStrategy();
        if(bs == null){//Check Buffer strategy is null Create it [if true]>>
            try{
                //Create Buffer Strategy
                createBufferStrategy(3);
                return;
            } catch (Exception e){
                return;
            }
        }
        //Create/Get Graphics(Painter) object g from BufferStrategy
        Graphics g = bs.getDrawGraphics();
        
        //START OF GRAPHICS
        ///////////////////////////////////////////////////////////////////////////////////////
        //Create Graphics2D(2D Painter) object from g
        Graphics2D g2d = (Graphics2D) g;
        
        //Set ANTIALIASING(Optional)
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        //Translate Canvas(Optional)
        //g2d.translate(4, 0);
        
        //Draw Background Image (Image full of black pixels)
        g2d.drawImage(img, 0, 0, gameWidth+10, gameHeight, null);
        
        g2d.setColor(Color.yellow);
        g2d.drawString(theFPS, 10, gameHeight-40);
        
        //stateManager.render(g2d);//Render another class using args g2d
        challenge.render(g2d);//Render another class using args Game, g2d
        
        
        ///////////////////////////////////////////////////////////////////////////////////////
        //END OF GRAPHICS
        
        g.dispose();//Dispose or clear g
        bs.show();//Show Buffer Strategy - Draw everything in g(g2d)
        
    }
    
    
    /**
     * getGameSound()
     * 
     * @return gameSndOn
     */
    private static boolean getGameSound() {
        return gameSndOn;
    }

    
    /**
     * setGameSound(boolean gameSndOn)
     * 
     * @param SndOn
     */
    public static void setGameSound(boolean SndOn) {
        Game.gameSndOn = SndOn;
    }
    
    
    /**
     * resetScore()
     */
    private void resetScore() {
        gameScore = 0;
    }

    /**
     * resetGameTime()
     */
    private void resetGameTime() {
        gameTimer = 0;
    }

    /**
     * quitGame()
     */
    public void quitGame() {
        stop();
        System.exit(0);
    }
    
    
}
