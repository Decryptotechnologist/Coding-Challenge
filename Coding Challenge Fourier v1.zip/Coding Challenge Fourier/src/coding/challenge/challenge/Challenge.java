/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import coding.challenge.graphics.Texture;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Ghomez
 */
public class Challenge {

    /**Attributes*/
    
    /**challengeNo variable of Challenge*/
    int challengeNo;
    
    /**challengeWidth variable of Challenge*/
    int challengeWidth;
    
    /**challengeHeight variable of Challenge*/
    int challengeHeight;
    
    /**firstTick variable of Challenge*/
    private boolean firstTick;
    
    /**lastTick variable of Challenge*/
    private boolean lastTick;
    
    /**challengeTime variable of Challenge*/
    private double challengeTime;
    
    /**fourierRadius variable of Challenge*/
    int fourierRadius;
    
    /**fourierRadius variable of Challenge*/
    int MAX_WAVE = 4000;
    
    /**wave variable of Challenge*/
    public int[] wave = new int[MAX_WAVE];
    
    /**waveX variable of Challenge*/
    public int[] waveX = new int[MAX_WAVE];
    
    /**waveY variable of Challenge*/
    public int[] waveY = new int[MAX_WAVE];
    
    /**waveList variable of Challenge*/
    public List<Integer> waveList = new LinkedList<>();
    
    /**random variable of Challenge*/
    public static Random random = new Random();
    
    
    
    /**Links*/
    
    
    
    /**Constructor*/
    
    /**
     * Challenge Constructor
     * 
     * @param ChallengeNo
     */
    public Challenge(int ChallengeNo){
        System.out.println("Challenge: new Challenge "+ChallengeNo+" created");
        this.challengeNo = ChallengeNo;
        
        setUp();
        
        init();
    }
    
    
    
    /**Public Protocol*/
    
    
    /**
     * setUp()
     *
     */
    private void setUp(){
        switch(challengeNo){
            case 1:
                setUpChallenge1();
                break;
        }
    }

    
    /**
     * setUpChallenge1()
     *
     */
    private void setUpChallenge1() {
        //Setup variables here for Challenge 1
        
        fourierRadius = 100;
    }
    
    
    /**
     * init()
     *
     */
    private void init(){
        Texture.clearMaps();
        

        firstTick = true;
        lastTick = false;
    }
    
    
    /**
     * render(Graphics2D g2d)
     *
     * @param g2d
     */
    public void render(Graphics2D g2d){
        //Render Challenge
        Graphics2D g2d_Challenge = g2d;
        AffineTransform oldXForm = g2d.getTransform();
        
        //Background(0) translated to >>
//        g2d_Challenge.setColor(Color.black);
//        g2d_Challenge.fillRect(0, 0, CCFourier.getMainWidth()/2, CCFourier.getMainHeight()/2);

        g2d_Challenge.translate(50, 200);
        
        //let radius = 100; translated to >>
       // int fourierRadius = 100;
        
        //stroke(255);
        //noFill();
        //ellipse(0, 0, radius * 2); translated to >>
        
        g2d_Challenge.setColor(Color.white);
        g2d_Challenge.drawOval(-6, -6, fourierRadius * 2, fourierRadius * 2);
        
        double xx = fourierRadius * Math.cos(challengeTime) + 90;
        double yy = fourierRadius * Math.sin(challengeTime) + 90;
        int x = (int) xx;
        int y = (int) yy;
        
        waveList.add(y);
        
        g2d_Challenge.setColor(Color.red);
        g2d_Challenge.drawLine(90, 90, x, y);
        g2d_Challenge.fillOval(x, y, 8, 8);
        
        Collections.reverse(waveList);
        g2d_Challenge.translate(300, 0);
        g2d_Challenge.setColor(Color.orange);
        
        g2d_Challenge.drawLine(x - 300, y, 0, waveList.get(0));
        
        for(int i = 0; i < waveList.size(); i++){
            waveX[i]= i;
            waveY[i] = waveList.get(i);
        }
        //System.out.println(waveList.toString());
        
        g2d_Challenge.setColor(getRandomColor());
        for(int index = 1; index < waveX.length; index++){
            g2d_Challenge.drawLine(waveX[index], waveY[index], waveX[index-1], waveY[index-1]);
        }
        
        g2d.setTransform(oldXForm);
        g2d_Challenge.setTransform(oldXForm);

    }
    
    
    /**
     * tick()
     *
     */
    public void tick(){
        //Handle First Tick
        if(firstTick){
            firstTick = false;
        }
        //Handle Last Tick
        if(lastTick){
            lastTick = false;
        }
        
        challengeTime += 0.1;//Update local timer
    }

    
    /**
     * getRandomColor()
     *
     */
    private Color getRandomColor() {
        int r = random.nextInt(255);
        int b = random.nextInt(255);
        int g = random.nextInt(255);
        
        return new Color(r, b, g).brighter();
    }
    
    
}
