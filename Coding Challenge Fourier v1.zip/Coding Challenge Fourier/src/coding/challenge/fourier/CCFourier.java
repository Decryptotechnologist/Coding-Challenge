/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.fourier;

import coding.challenge.graphics.Texture;
import coding.challenge.gui.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import javax.swing.border.Border;

/**
 *
 * @author Ghomez
 */
public class CCFourier {

    /**Attributes*/
    
    /**frame variable of CCSandbox*/
    JFrame frame;
    
    /**panel variable of CCSandbox*/
    JPanel panel;
    
    /**raisedBevel variable of CCSandbox*/
    Border raisedBevel;
    
    /**mainWidth variable of CCSandbox*/
    static int mainWidth;
    
    /**mainHeight variable of CCSandbox*/
    static int mainHeight;
    
    /**icon variable of CCSandbox*/
    private BufferedImage icon;
    
    
    
    /**Links*/
    
    /**menuBR MainMenu of CCSandbox*/
    private final MainMenu menuBR;
    
    /**statusBar StatusBar of CCSandbox*/
    private final StatusBar statusBar;
    
    /**game Game of CCSandbox*/
    public Game game;
    
    
    
    
    
    /**Constructor*/
    
    
    /**
     * CCFourier Constructor
     *
     */
    public CCFourier(){
        System.out.println("CCFourier: New CCFourier created");
        
        setIcon();
        setLAF();
        
        //Create new JFrame: frame(Game.TITLE+" "+Game.version)
        frame = new JFrame(Game.TITLE+" "+Game.version);
        
        //Create new Game: Game()
        game = new Game(getMainWidth(), getMainHeight());
        
        //Create new MainMenu: MainMenu(game)
        menuBR = new MainMenu(game);
        
        //Create size: new Dimension(getMainWidth(), getMainHeight())
        Dimension size = new Dimension(getMainWidth(), getMainHeight());
        
        //Create panel: new JPanel(new BorderLayout())
        panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(size);
        
        //Create new StatusBar: statusBar("", SwingConstants.CENTER, raisedBevel)
        statusBar = new StatusBar("Ready.", SwingConstants.CENTER, raisedBevel);
        statusBar.setVisible(true);
        
        panel.add(game, BorderLayout.CENTER);
        panel.add(statusBar, BorderLayout.SOUTH);
        
        
        //Setup frame
        frame.setSize(size);
        frame.setContentPane(panel);
        frame.setIconImage(icon);
        frame.pack();
        
        frame.setVisible(true);
        frame.setJMenuBar(menuBR);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        
        frame.addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e){
                System.err.println("Exiting Game . . .");
                game.quitGame();
            }
        }); 
        
        
    }
    
    
    /**Public Protocol*/
    
    /**
     * getMainWidth()
     * 
     * @return 
     */
    public static int getMainWidth(){
        if(mainWidth < 840){
            setMainWidth(840);
        }
        return mainWidth;
    }
    
    
    /**
     * setMainWidth(int width)
     * 
     * @param width
     */
    private static void setMainWidth(int width) {
        mainWidth = width;
    }

    
    /**
     * getMainHeight()
     * 
     * @return 
     */
    public static int getMainHeight(){
        if(mainHeight < 700){
            setMainHeight(700);
        }
        return mainHeight;
    }
    
    
    /**
     * setMainHeight(int height)
     * 
     * @param height 
     */
    private static void setMainHeight(int height) {
        mainHeight = height;
    }
    
    /**
     * setIcon()
     */
    private void setIcon() {
        this.icon = new Texture("/icon/CCS-icon-16").getImage();
    }

    
    /**
     * setLAF()
     */
    private void setLAF() {
        raisedBevel = BorderFactory.createRaisedBevelBorder();
    }

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Splashscreen code here
        
        // TODO code application logic here
        CCFourier ccF = new CCFourier();
        
    }
    
}
