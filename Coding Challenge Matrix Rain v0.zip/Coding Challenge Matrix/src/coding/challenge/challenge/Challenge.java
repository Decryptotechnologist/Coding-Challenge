/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import coding.challenge.graphics.Texture;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.Random;

/**
 *
 * @author Ghomez
 */
public class Challenge {

    /**Attributes*/
    
    /**challengeNo variable of Challenge*/
    int challengeNo;
    
    /**challengeWidth variable of Challenge*/
    int challengeWidth;
    
    /**challengeHeight variable of Challenge*/
    int challengeHeight;
    
    /**firstTick variable of Challenge*/
    private boolean firstTick;
    
    /**lastTick variable of Challenge*/
    private boolean lastTick;
    
    /**x variable of Challenge*/
    public int x = 0;
    
    /**y variable of Challenge*/
    public int y = 0;
    
    /**random variable of Challenge*/
    public static Random random = new Random();
    
    /**streams variable of Challenge*/
    private Stream[] streams;
    
    /**acomp variable of Challenge*/
    private AlphaComposite acomp;
    
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * Challenge Constructor
     * 
     * @param ChallengeNo
     * @param w
     * @param h
     */
    public Challenge(int ChallengeNo, int w, int h){
        System.out.println("Challenge: new Challenge "+ChallengeNo+" created");
        this.challengeNo = ChallengeNo;
        this.challengeWidth = w;
        this.challengeHeight = h;
        
        setUp();
        
        init();
    }
    
    /**Public Protocol*/
    
    /**
     * setUp()
     *
     */
    private void setUp(){
        switch(challengeNo){
            case 1:
                setUpChallenge1();
                break;
        }
    }

    /**
     * setUpChallenge1()
     *
     */
    private void setUpChallenge1() {
        //Setup variables here for Challenge 1
        streams = new Stream[challengeWidth/22];
        
        for(int i = 0; i <= streams.length-1; i++){
            streams[i] = new Stream();
            streams[i].generateSymbols(x, 0);
            x += 24;
        }
        
    }
    
    /**
     * init()
     *
     */
    private void init(){
        Texture.clearMaps();        

        firstTick = true;
        lastTick = false;
    }
    
    
    /**
     * render(Graphics2D g2d)
     *
     * @param g2d
     */
    public void render(Graphics2D g2d){
        //Render Challenge
        Graphics2D g2d_Challenge = g2d;
        AffineTransform oldXForm = g2d.getTransform();
        
        //Background(0) translated to >>
//        g2d_Challenge.setColor(Color.black);
//        g2d_Challenge.fillRect(0, 0, CCMatrix.getMainWidth(), CCMatrix.getMainHeight());


        g2d_Challenge.setFont(new Font("default", Font.BOLD, 20));
        
        for(int i = 0; i <= streams.length-1; i++){
            acomp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, streams[i].alpha);
            g2d_Challenge.setComposite(acomp);
            
            for(int j = 0; j <= streams[i].symbols.length-1; j++){
                if(streams[i].symbols[j].first && i % 2 == 0){
                    g2d_Challenge.setColor(new Color(0x00FF41));
                    g2d_Challenge.drawString(streams[i].symbols[j].value, streams[i].symbols[j].symbolX+1, streams[i].symbols[j].symbolY+1);
                    g2d_Challenge.setColor(Color.white);
                    g2d_Challenge.drawString(streams[i].symbols[j].value, streams[i].symbols[j].symbolX, streams[i].symbols[j].symbolY);
                } else {
                    g2d_Challenge.setColor(new Color(0x008F11));
                    g2d_Challenge.drawString(streams[i].symbols[j].value, streams[i].symbols[j].symbolX+1, streams[i].symbols[j].symbolY+1);
                    g2d_Challenge.setColor(new Color(0x00FF41));
                    g2d_Challenge.drawString(streams[i].symbols[j].value, streams[i].symbols[j].symbolX, streams[i].symbols[j].symbolY);
                }
                streams[i].symbols[j].move();
            }
        }
        
        //Reset Alpha
        acomp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f);
        g2d_Challenge.setComposite(acomp);
        
        //Reset Font
        g2d_Challenge.setFont(new Font("default", Font.PLAIN, 12));
        
        //Reset Transform
        g2d.setTransform(oldXForm);
        g2d_Challenge.setTransform(oldXForm);
    }
    
    
    
    /**
     * tick()
     *
     */
    public void tick(){
        //Handle First Tick
        if(firstTick){
            firstTick = false;
            
        }
        //Handle Last Tick
        if(lastTick){
            lastTick = false;
            
        }
        
        for(int i = 0; i <= streams.length-1; i++){
            for(int j = 0; j <= streams[i].symbols.length-1; j++){
                if(System.nanoTime() / 450 % streams[i].symbols[j].switchInterval == 0){
                    streams[i].symbols[j] = new Symbol(streams[i].symbols[j].symbolX, streams[i].symbols[j].symbolY, streams[i].symbols[j].speed, streams[i].symbols[j].first);
                }
            }
        }
        
    }
    
}
