/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import java.util.Random;

/**
 *
 * @author Ghomez
 */
public class Stream {
    
    /**Attributes*/
    
    /**random variable of Challenge*/
    public static Random random = new Random();
    
    /**totalSymbols variable of Stream*/
    public int totalSymbols;
    
    /**symbols variable of Stream*/
    public Symbol[] symbols;
    
    /**symbol variable of Stream*/
    public Symbol symbol;
    
    /**speed variable of Stream*/
    public int speed;
    
    /**symbolSize variable of Stream*/
    public int symbolSize = 24;
    
    /**alpha variable of Stream*/
    public float alpha;
    
    
    public Stream(){
        this.totalSymbols = random.nextInt(25) + 5;
        this.symbols = new Symbol[totalSymbols];
        this.speed = random.nextInt(8) + 1;
        this.alpha = random.nextFloat() + 0.1f;
        
        if(alpha > 1.0f) alpha = 1.0f;
    }
    
    
    public void generateSymbols(int x_, int y_){
        boolean first = true;
        for(int i = 0; i <= totalSymbols-1; i++){
            this.symbol = new Symbol(x_, y_, this.speed, first);
            this.symbols[i] = symbol;
            y_ -= symbolSize;
            first = false;
        }
        
    }
    
    
}
