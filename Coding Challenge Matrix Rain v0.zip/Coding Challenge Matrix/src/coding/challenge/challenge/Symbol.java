/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import coding.challenge.matrix.CCMatrix;
import java.util.Random;

/**
 *
 * @author Ghomez
 */
public class Symbol {
    
    /**Attributes*/
    
    /**random variable of Symbol*/
    public static Random random = new Random();
    
    /**x variable of Symbol*/
    public int symbolX;
    
    /**y variable of Symbol*/
    public int symbolY;
    
    /**value variable of Symbol*/
    public String value;
    
    /**speed variable of Symbol*/
    public int speed;
    
    /**switchInterval variable of Symbol*/
    public int switchInterval;
    
    /**switchInterval variable of Symbol*/
    public boolean first;
    
    
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * Symbol Constructor
     * 
     * @param x_
     * @param y_
     * @param speed_
     * @param first_
     * 
     */
    public Symbol(int x_, int y_, int speed_, boolean first_){
        this.symbolX = x_;
        this.symbolY = y_;
        this.speed = speed_;
        this.switchInterval = Math.round(random.nextInt(18) + 2);
        this.first = first_;
        
        int codePoint = '\u30A0' + Math.round(random.nextInt(95)+1);
        this.value = Character.toString((char) codePoint);
    }
    
    
    public void move(){
        //this.y = (this.y >= CCMatrix.getMainHeight()) ? 0 : this.y += this.speed; Translated to >>
        if(this.symbolY >= CCMatrix.getMainHeight()){
            this.symbolY = 0;
        } else {
            this.symbolY += this.speed;
        }
        
    }
}
