/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.challenge;

import coding.challenge.graphics.Texture;
import java.awt.*;

/**
 *
 * @author Ghomez
 */
public class Challenge {

    /**Attributes*/
    
    /**challengeNo variable of Challenge*/
    int challengeNo;
    
    /**challengeWidth variable of Challenge*/
    int challengeWidth;
    
    /**challengeHeight variable of Challenge*/
    int challengeHeight;
    
    /**firstTick variable of Challenge*/
    private boolean firstTick;
    
    /**lastTick variable of Challenge*/
    private boolean lastTick;
    
    /**challengeTime variable of Challenge*/
    private int challengeTime;
    
    
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * Challenge Constructor
     * 
     * @param ChallengeNo
     * @param w
     * @param h
     */
    public Challenge(int ChallengeNo, int w, int h){
        System.out.println("Challenge: new Challenge "+ChallengeNo+" created");
        this.challengeNo = ChallengeNo;
        this.challengeWidth = w;
        this.challengeHeight = h;
        
        setUp();
        
        init();
    }
    
    /**Public Protocol*/
    
    /**
     * setUp()
     *
     */
    private void setUp(){
        switch(challengeNo){
            case 1:
                setUpChallenge1();
                break;
        }
    }

    private void setUpChallenge1() {
        //Setup variables here for Challenge 1
        
        
    }
    
    private void init(){
        Texture.clearMaps();
        
        //Game.enemies = new Enemy();//Create new objects for this class to conrol
        
        //Enemy.init();//Initiate new objects
        
        //Setup Background Image: (Optional)
        //challengeBGIMG = new Texture("/level/GD1-LevelBG-1b").getImage();
        

        firstTick = true;
        lastTick = false;
    }
    
    
    /**
     * render(Graphics2D g2d)
     *
     * @param g2d
     */
    public void render(Graphics2D g2d){
        //Render Challenge
        
    
    }
    
    /**
     * tick()
     *
     */
    public void tick(){
        //Handle First Tick
        if(firstTick){
            firstTick = false;
            //Game.resetGameTime();//Reset Game Timer(Optional)
            
            
        }
        //Handle Last Tick
        if(lastTick){
            lastTick = false;
//            Sound.stopAll();
//            if(!Sound.endOfLevel.isPlaying()){
//                Sound.endOfLevel.play();
//            }
            
        }
        
        //Enemy.tick();//Tick (update) other classes
        
        challengeTime++;//Update local timer
    }
    
}
