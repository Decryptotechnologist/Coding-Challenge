/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.graphics;


import coding.challenge.sandbox.Game;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author Ghomez
 */
public class Texture {
    
    /**Attributes*/
    
    /**texMap Map<String, BufferedImage> of Texture object*/
    static Map<String, BufferedImage> texMap = new HashMap<String, BufferedImage>();
    
    /**renMap Map<String, Render> of Texture object*/
    static Map<String, Render> renMap = new HashMap<String, Render>();
    
    /**Attributes*/
    static Render render;
    
    /**Attributes*/
    static String renderFileName;
    
    /**Attributes*/
    static int renWidth;
    
    /**Attributes*/
    static int renHeight;
    
    /**Attributes*/
    static BufferedImage renIMG;
    
    /**Attributes*/
    BufferedImage img;
    
    /**Attributes*/
    String fileName;
    
    /**Attributes*/
    String filePath;
    
    /**Attributes*/
    static int width;
    
    /**Attributes*/
    static int height;
    
    
    //public static final Render p1 = loadBitmap("/Sprites/player1a.png");
    
    //public static final Render spriteSheet1 = loadBitmap("/Sprites/GD1-spriteSheet-1.png");
    
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * Texture Constructor
     * 
     * 
     * @param fileName
     */
    public Texture(String fileName){
        this.fileName = fileName;
        this.filePath = "res"+fileName+".png";
        BufferedImage oldTex = texMap.get(fileName);
        if(oldTex != null){
            this.img = oldTex;
        } else {
            try {
                System.out.println("Texture: Loading Texture: "+Game.textCount+": "+fileName);
                this.img = ImageIO.read(Texture.class.getResource(fileName+".png"));
                texMap.put(fileName, img);
                Game.textCount++;
            } catch (IOException e){
                Logger.getLogger(Texture.class.getName()).log(Level.SEVERE, null, e);
            }
            
            this.width = img.getWidth();
            this.height = img.getHeight();
               
        }
        
    }
    
    public static Render loadBitmap(String fileName){
        renderFileName = fileName;
        
        Render oldRen = renMap.get(fileName);
        if(oldRen != null){
            render = oldRen;
        } else {
            try {
                System.out.println("Texture: Loading Render: "+Game.renderCount+": "+renderFileName);
                renIMG = ImageIO.read(Texture.class.getResource(renderFileName));
                renWidth = renIMG.getWidth();
                renHeight = renIMG.getHeight();
                render = new Render(renWidth, renHeight);
                renIMG.getRGB(0, 0, renWidth, renHeight, render.pixels, 0, renWidth);
                for(int i = 0; i < render.pixels.length; i++){
                    int in = render.pixels[i];
                    int col = (in & 0xf) >> 2;
                    if(in == 0xffff00ff){
                        col = -1;
                    }
                    render.pixels[i] = col;
                }
                renMap.put(renderFileName, render);
                Game.renderCount++;
            } catch (IOException e){
                Logger.getLogger(Texture.class.getName()).log(Level.SEVERE, null, e);
            }
               
        }
        return renMap.get(renderFileName);
    }
    
    
    /**
     * getImage()
     * 
     * @return img
     */
    public BufferedImage getImage(){
        return img;
    }
    
    /**
     * clearMaps()
     * 
     */
    public static void clearMaps() {
        texMap.clear();
        renMap.clear();
    }
    
}
