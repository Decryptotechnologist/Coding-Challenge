/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coding.challenge.gui;

import com.sun.glass.events.KeyEvent;
import coding.challenge.sandbox.Game;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author Ghomez
 */
public class MainMenu extends JMenuBar {
    
    /**Attributes*/
    
    /**Links*/
    
    /**Constructor*/
    
    /**
     * MainMenu Constructor
     */
    public MainMenu(Game game){
        System.out.println("MainMenu: New MainMenu created");
        
        //GAME
        JMenu fileMenu = new JMenu("Game");
        
            //GAME : NEW GAME
            JMenuItem newMi = new JMenuItem("New Game");
            KeyStroke f3 = KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0);
            newMi.setAccelerator(f3);
            newMi.setMnemonic(KeyEvent.VK_F3);
            
            newMi.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e){
                    System.out.println("New Game Clicked!");
                }
            });
            
        
            //GAME : EXIT GAME
            JMenuItem exitMi = new JMenuItem("Exit Game");
            KeyStroke f4 = KeyStroke.getKeyStroke(KeyEvent.VK_F4, 0);
            exitMi.setAccelerator(f4);
            exitMi.setMnemonic(KeyEvent.VK_F4);
            
            exitMi.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e){
                    System.out.println("Exit Game Clicked!");
                    game.quitGame();
                }
            });
            
        
        //HELP
        JMenu helpMenu = new JMenu("Help");
        
            //HELP : HELP
            JMenuItem helpMi = new JMenuItem("Help");
            KeyStroke h = KeyStroke.getKeyStroke(KeyEvent.VK_H, 0);
            helpMi.setAccelerator(h);
            helpMi.setMnemonic(KeyEvent.VK_H);
            
            helpMi.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e){
                    System.out.println("Help Clicked!");
                }
            });
        
            
        fileMenu.add(newMi);
        fileMenu.add(exitMi);
        
        helpMenu.add(helpMi);
        
        
        this.add(fileMenu);
        this.add(Box.createHorizontalGlue());
        this.add(helpMenu);
        
        this.setVisible(true);
        this.setOpaque(true);
    }
    
    /**Public Protocol*/
    
}
